local var = nil
print( var.bad )
