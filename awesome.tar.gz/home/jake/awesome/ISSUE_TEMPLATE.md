Output of `awesome --version`:

_REPLACE with full version output_

**How to reproduce the issue:**

_REPLACE with step-by-step instructions on what to do_

**Actual result:**

_REPLACE with what happened_

**Expected result:**

_REPLACE with what should happen_
