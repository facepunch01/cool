#ifndef _AWE_VERSION_INTERNAL_H_
#define _AWE_VERSION_INTERNAL_H_

#define AWESOME_VERSION             "@AWESOME_VERSION@"
#define AWESOME_RELEASE             "@AWESOME_RELEASE@"
#define AWESOME_API_LEVEL           @AWESOME_API_LEVEL@

#endif //_AWE_VERSION_INTERNAL_H_

// vim: filetype=c:expandtab:shiftwidth=4:tabstop=8:softtabstop=4:textwidth=80
